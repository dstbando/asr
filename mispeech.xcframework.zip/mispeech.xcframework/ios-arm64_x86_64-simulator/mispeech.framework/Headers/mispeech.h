//
//  mispeech.h
//  mispeech
//
//  Created by Takashi Bando on 4/17/24.
//

#import <Foundation/Foundation.h>

//! Project version number for mispeech.
FOUNDATION_EXPORT double mispeechVersionNumber;

//! Project version string for mispeech.
FOUNDATION_EXPORT const unsigned char mispeechVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <mispeech/PublicHeader.h>


