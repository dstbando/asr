//
//  asr.h
//  asr
//
//  Created by Takashi Bando on 4/16/24.
//

#import <Foundation/Foundation.h>

//! Project version number for asr.
FOUNDATION_EXPORT double asrVersionNumber;

//! Project version string for asr.
FOUNDATION_EXPORT const unsigned char asrVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <asr/PublicHeader.h>


